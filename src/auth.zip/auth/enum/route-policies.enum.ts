export enum RoutePolicies {
  createUser = 'createUser',
  findOneUser = 'findOneUser',
  findAllUsers = 'findAllUsers',
  updateUser = 'updateUser',
  deleteUser = 'deleteUser',
}